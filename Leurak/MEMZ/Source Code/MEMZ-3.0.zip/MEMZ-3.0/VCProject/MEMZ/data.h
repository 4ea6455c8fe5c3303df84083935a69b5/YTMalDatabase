extern const unsigned char msg[];
extern const char *sites[];
extern const char *msgs[];
extern const char *sounds[];

extern const size_t nSites;
extern const size_t nSounds;
extern const size_t nMsgs;

extern const unsigned char code1[];
extern const unsigned char code2[];

extern const size_t code1_len;
extern const size_t code2_len;
extern const size_t msg_len;